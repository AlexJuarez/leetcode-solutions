// Source : https://leetcode.com/problems/powx-n/
// Author : Han Zichi
// Date   : 2015-08-10

/**
 * @param {number} x
 * @param {number} n
 * @return {number}
 */

var myPow = function(x, n) {
  return Math.pow(x, n);
};