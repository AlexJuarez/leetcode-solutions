// Source : https://leetcode.com/problems/sqrtx/
// Author : Han Zichi
// Date   : 2015-08-09

/**
 * @param {number} x
 * @return {number}
 */

// I really do not know what the meaning of this problem is
var mySqrt = function(x) {
  return Math.floor(Math.sqrt(x));
};