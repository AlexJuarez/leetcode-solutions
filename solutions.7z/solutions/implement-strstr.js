// Source : https://leetcode.com/problems/implement-strstr/
// Author : Han Zichi
// Date   : 2015-08-23

/**
 * @param {string} haystack
 * @param {string} needle
 * @return {number}
 */
var strStr = function(haystack, needle) {
  return haystack.search(needle);
};